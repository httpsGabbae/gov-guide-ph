import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { searchCharterTool, getServiceRequirementsTool } from '@/lib/ai/tools';
import { getGeminiClient, GEMINI_FLASH_MODEL } from '@/lib/ai/models';
import { createServiceClient } from '@/lib/supabase/service';
import { evaluateGuardrails } from '@/lib/ai/guardrails';
import { searchQABank, detectServiceFromQuery } from '@/lib/rag/qa-matcher';
import { getServiceByCode, listAllServices } from '@/lib/services/registry';
import { OFFICIAL_CONTACTS } from '@/lib/rag/answer';
import { queryDpwhProjects } from '@/lib/dpwh/projects';

const chatRequestSchema = z.object({
  messages: z.array(
    z.object({
      role: z.enum(['user', 'assistant', 'system']),
      content: z.string(),
    }),
  ),
  language: z.enum(['fil', 'en']).default('fil'),
  sessionId: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const json = await req.json();
    const parseResult = chatRequestSchema.safeParse(json);

    if (!parseResult.success) {
      return NextResponse.json(
        { error: 'Invalid chat request body', details: parseResult.error.format() },
        { status: 400 },
      );
    }

    const { messages, language, sessionId = 'anon-session' } = parseResult.data;
    const lastUserMessage = [...messages].reverse().find((m) => m.role === 'user')?.content || '';

    // Step 0: Run Multi-Layer Civic Guardrails (Secret exfiltration, Prompt Injection, Fixer, Forgery, Privacy)
    const mockApplicant = {
      id: sessionId,
      role: 'jobseeker' as const,
      display_name: 'Citizen Applicant',
      initials: 'CA',
      title: 'Applicant',
      birth_date: '2000-01-01',
      civil_status: 'Single',
      barangay: 'Barangay 1',
      city: 'Manila',
    };

    const guardrailCheck = evaluateGuardrails(lastUserMessage, mockApplicant, language);

    const encoder = new TextEncoder();

    if (guardrailCheck.blocked && guardrailCheck.category !== 'OUT_OF_SCOPE') {
      const stream = new ReadableStream({
        start(controller) {
          const sendEvent = (data: Record<string, unknown>) => {
            controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
          };

          sendEvent({
            type: 'guardrail_blocked',
            category: guardrailCheck.category,
            card: guardrailCheck.guardrailCard,
            suggestedNext: guardrailCheck.suggestedNext,
          });

          sendEvent({
            type: 'token',
            content: guardrailCheck.replyText,
          });

          sendEvent({ type: 'done' });
          controller.close();
        },
      });

      return new Response(stream, {
        headers: {
          'Content-Type': 'text/event-stream; charset=utf-8',
          'Cache-Control': 'no-cache, no-transform',
          Connection: 'keep-alive',
        },
      });
    }

    // Step 1: Detect intent and resolve service code across 15 government services
    let serviceCode: string | null = null;
    const lower = lastUserMessage.toLowerCase();

    if (lower.includes('nbi') || lower.includes('clearance')) {
      serviceCode = 'NBI_CLEARANCE';
    } else if (lower.includes('birth') || lower.includes('secpa') || (lower.includes('psa') && !lower.includes('marriage') && !lower.includes('cenomar'))) {
      serviceCode = 'PSA_BIRTH_CERT';
    } else if (lower.includes('marriage') || lower.includes('kasal')) {
      serviceCode = 'PSA_MARRIAGE_CERT';
    } else if (lower.includes('cenomar') || lower.includes('singleness')) {
      serviceCode = 'PSA_CENOMAR';
    } else if (lower.includes('philhealth') || lower.includes('pmrf') || lower.includes('mdr')) {
      serviceCode = 'PHILHEALTH_REGISTRATION';
    } else if (lower.includes('sss') || lower.includes('social security') || lower.includes('ssn') || lower.includes('e-1')) {
      serviceCode = 'SSS_REGISTRATION';
    } else if (lower.includes('pag-ibig') || lower.includes('pagibig') || lower.includes('hdmf')) {
      serviceCode = 'PAGIBIG_MEMBERSHIP';
    } else if (lower.includes('passport') || lower.includes('dfa')) {
      serviceCode = 'DFA_PASSPORT';
    } else if (lower.includes('business name') || lower.includes('dti') || lower.includes('bnrs')) {
      serviceCode = 'DTI_BUSINESS_NAME';
    } else if (lower.includes('tin') || lower.includes('bir') || lower.includes('orus')) {
      serviceCode = 'BIR_TIN';
    } else if (lower.includes('prc') || lower.includes('leris') || lower.includes('board exam')) {
      serviceCode = 'PRC_LERIS';
    } else if (lower.includes('student permit') || lower.includes('lto') || lower.includes('driver')) {
      serviceCode = 'LTO_STUDENT_PERMIT';
    } else if (lower.includes('aics') || lower.includes('dswd') || lower.includes('financial assistance')) {
      serviceCode = 'DSWD_AICS';
    } else if (lower.includes('national id') || lower.includes('philsys') || lower.includes('ephilid')) {
      serviceCode = 'NATIONAL_ID';
    } else if (lower.includes('pwd') || lower.includes('disability') || lower.includes('ncda') || lower.includes('pdao')) {
      serviceCode = 'PWD_ID';
    } else if (
      lower.includes('dpwh') ||
      lower.includes('infrastructure') ||
      lower.includes('bridge') ||
      lower.includes('expressway') ||
      lower.includes('flood control') ||
      lower.includes('bataan-cavite') ||
      lower.includes('samal') ||
      lower.includes('panguil') ||
      lower.includes('davao city bypass')
    ) {
      serviceCode = 'DPWH_PROJECTS';
    }

    const agencyCode = serviceCode
      ? serviceCode.split('_')[0]
      : undefined;

    // Search Citizen Charters (Vector RAG)
    const toolSearchResults = await searchCharterTool({
      query: lastUserMessage,
      agency_code: agencyCode,
    });

    // Also search 1,000 Q&A Research Bank
    const qaSearchResults = searchQABank(lastUserMessage, {
      topK: 3,
      threshold: 0.35,
    });

    const serviceInfo = serviceCode ? await getServiceRequirementsTool({ service_code: serviceCode }) : null;

    // Live DPWH Nationwide Projects lookup when query relates to DPWH infrastructure
    const dpwhQueryResult =
      serviceCode === 'DPWH_PROJECTS'
        ? (() => {
            const direct = queryDpwhProjects({ search: lastUserMessage });
            return direct.projects.length > 0 ? direct : queryDpwhProjects();
          })()
        : null;
    const dpwhMatchedProjects = dpwhQueryResult ? dpwhQueryResult.projects.slice(0, 4) : [];

    // Stream Setup using Server-Sent Events (SSE)
    const stream = new ReadableStream({
      async start(controller) {
        const sendEvent = (data: Record<string, unknown>) => {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
        };

        // Notify client of tool execution
        sendEvent({
          type: 'tool_call',
          tool: 'search_charter',
          query: lastUserMessage,
          resultsFound: toolSearchResults.count + dpwhMatchedProjects.length,
        });

        // Fallback condition: Neither charter chunks, Q&A bank, nor DPWH projects match
        if (toolSearchResults.count === 0 && qaSearchResults.length === 0 && dpwhMatchedProjects.length === 0) {
          let fallbackContact = OFFICIAL_CONTACTS.NBI;
          if (serviceCode) {
            const prefix = serviceCode.split('_')[0];
            if (OFFICIAL_CONTACTS[prefix]) {
              fallbackContact = OFFICIAL_CONTACTS[prefix];
            } else if (serviceCode === 'NATIONAL_ID') {
              fallbackContact = OFFICIAL_CONTACTS.NATIONAL_ID;
            } else if (serviceCode === 'PWD_ID') {
              fallbackContact = OFFICIAL_CONTACTS.PWD_ID;
            }
          }

          // Asynchronously log unanswered query
          try {
            const supabase = createServiceClient();
            await (supabase as unknown as { from: (table: string) => { insert: (data: unknown) => Promise<unknown> } })
              .from('chat_unanswered')
              .insert({
                session_id: sessionId,
                user_query: lastUserMessage,
                reason: 'LOW_CONFIDENCE_BELOW_0.65',
                metadata: { language, serviceCode },
              });
          } catch {
            // safe ignore in offline test
          }

          sendEvent({
            type: 'fallback',
            contact: fallbackContact,
          });

          const fallbackText =
            language === 'en'
              ? `I apologize, but the official Citizen's Charter does not contain certified provisions matching your specific query. To avoid misinformation or repeat queues ("balik-pila"), please reach out directly to the official Public Assistance Desk.`
              : `Paumanhin, ngunit walang opisyal na probisyon sa Citizen's Charter ukol sa iyong katanungan. Upang maiwasan ang maling impormasyon at 'balik-pila' sa counter, mangyaring sumangguni sa opisyal na Public Assistance Desk ng ahensya.`;

          sendEvent({ type: 'token', content: fallbackText });
          sendEvent({ type: 'done' });
          controller.close();
          return;
        }

        // Send sources and structured checklist
        const combinedSources = [
          ...toolSearchResults.results.map((r) => ({
            agency: r.agency,
            service: r.service,
            section: r.section,
            breadcrumb: r.breadcrumb,
            similarity: r.similarity,
          })),
          ...qaSearchResults.map((q) => ({
            agency: q.entry.service || 'GovGuide PH Knowledge Base',
            service: q.entry.service || q.entry.section,
            section: q.entry.section,
            breadcrumb: `${q.entry.section} (${q.entry.id})`,
            similarity: q.score,
          })),
          ...dpwhMatchedProjects.map((p) => ({
            agency: 'Department of Public Works and Highways (DPWH)',
            service: 'Nationwide Infrastructure Tracker',
            section: `${p.region} • ${p.category}`,
            breadcrumb: `[DPWH Contract ${p.contractId}] ${p.title} (${p.physicalProgress}% Complete)`,
            similarity: 0.92,
          })),
        ];

        sendEvent({
          type: 'sources',
          sources: combinedSources.slice(0, 5),
        });

        if (serviceInfo?.found && serviceInfo.service) {
          sendEvent({
            type: 'checklist',
            serviceName: serviceInfo.service.name,
            agencyName: serviceInfo.service.agencyName,
            requirements: serviceInfo.service.requirements,
            processingFee: serviceInfo.service.processingFee,
            convenienceFee: serviceInfo.service.convenienceFee,
            counterReadyTips: serviceInfo.service.counterReadyTips,
          });
        }

        // Stream answer from Gemini Flash (or deterministic stream on timeout/offline)
        const apiKey = process.env.GEMINI_API_KEY;
        if (apiKey && apiKey !== 'your_gemini_api_key_here') {
          try {
            const ai = getGeminiClient();
            const charterContext = toolSearchResults.results
              .map((r, i) => `[Source ${i + 1}: ${r.breadcrumb}]\n${r.content}`)
              .join('\n\n---\n\n');

            const qaContext = qaSearchResults
              .map((q, i) => `[Vetted Q&A ${i + 1}: ${q.entry.question}]\nAnswer: ${q.entry.answer}`)
              .join('\n\n---\n\n');

            const dpwhContext =
              dpwhMatchedProjects.length > 0
                ? dpwhMatchedProjects
                    .map(
                      (p) =>
                        `[DPWH Contract ${p.contractId}: ${p.title}]\nRegion: ${p.region} (${p.islandGroup}) | Location: ${p.cityMunicipality}, ${p.province}\nPhysical Progress: ${p.physicalProgress}% | Budget: ₱${(p.budgetPhp / 1_000_000_000).toFixed(2)}B | Target Completion: ${p.targetCompletionDate}\nSummary: ${p.description}`
                    )
                    .join('\n\n')
                : '';

            const fullContext = [charterContext, qaContext, dpwhContext]
              .filter(Boolean)
              .join('\n\n=== ADDITIONAL RESEARCH KNOWLEDGE ===\n\n');

            const langInstruction =
              language === 'fil'
                ? 'Answer in warm, clear, reassuring Filipino/Taglish. Greet the citizen respectfully.'
                : 'Answer in professional, clear, reassuring Philippine civic English.';

            const prompt = `You are GovGuide PH, the official AI Citizen's Charter assistant for Philippine Government transactions.
${langInstruction}

Strict Grounding Rules:
1. ONLY state facts, requirements, fees, and procedures explicitly present in the Official Context below.
2. Cite sources with square brackets (e.g. [NBI Clearance Charter > Documentary Requirements]).
3. Warn against common counter rejection mistakes (e.g., lack of photocopies, unreadable SECPA barcodes, expired IDs).
4. Do NOT promise approval; clarify that GovGuide PH is a preparation platform to eliminate balik-pila.

Citizen Question: "${lastUserMessage}"

Official Context:
${fullContext}

Assistant:`;

            // Race against 4.5-second timeout for streaming
            const streamPromise = ai.models.generateContentStream({
              model: GEMINI_FLASH_MODEL,
              contents: prompt,
            });

            const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 4500));
            const streamResult = await Promise.race([streamPromise, timeoutPromise]);

            if (streamResult) {
              for await (const chunk of streamResult) {
                const text = chunk.text;
                if (text) {
                  sendEvent({ type: 'token', content: text });
                }
              }

              sendEvent({ type: 'done' });
              controller.close();
              return;
            }
          } catch (err) {
            console.warn('[api/chat] Gemini streaming error, falling back to deterministic stream:', err);
          }
        }

        // Deterministic stream for tests / offline mode / API timeout
        if (toolSearchResults.results.length > 0) {
          const topResult = toolSearchResults.results[0];
          const lines = [
            language === 'fil'
              ? `Magandang araw! Batay sa opisyal na **${topResult.agency} Citizen's Charter** (${topResult.section}):`
              : `Good day! Based on the official **${topResult.agency} Citizen's Charter** (${topResult.section}):`,
            '',
            topResult.content
              .split('\n')
              .filter((l) => l.trim() && !l.startsWith('#'))
              .slice(0, 4)
              .join('\n'),
            '',
            `📌 **Opisyal na Pinagbatayan:** [${topResult.breadcrumb}]`,
            language === 'fil'
              ? `💡 *Paalala:* Tiyaking dalhin ang orihinal na dokumento at 2 malinaw na photocopy upang 100% Counter Ready ka na sa pila!`
              : `💡 *Reminder:* Bring the original document plus 2 clear photocopies so you are 100% Counter Ready!`,
          ];

          for (const line of lines) {
            sendEvent({ type: 'token', content: line + '\n' });
          }
        } else if (dpwhMatchedProjects.length > 0 && dpwhQueryResult) {
          const stats = dpwhQueryResult.stats;
          const lines = [
            language === 'fil'
              ? `Magandang araw! Narito ang mga aktibong proyekto ng **Department of Public Works and Highways (DPWH)** sa buong Pilipinas (${stats.nationwideTotal} Flagship Projects, Average Progress: ${stats.averageProgress}%):`
              : `Good day! Here are the active **Department of Public Works and Highways (DPWH)** infrastructure projects across the Philippines (${stats.nationwideTotal} Flagship Projects, Average Progress: ${stats.averageProgress}%):`,
            '',
            ...dpwhMatchedProjects.map(
              (p) =>
                `• **${p.title}** (${p.cityMunicipality}, ${p.province} — ${p.region}): **${p.physicalProgress}% Complete** | Budget: ₱${(p.budgetPhp / 1_000_000_000).toFixed(2)}B | Target: ${p.targetCompletionDate} [DPWH Contract ${p.contractId}]`
            ),
            '',
            `📌 **Pinagbatayan:** [DPWH Nationwide Infrastructure Transparency Portal 2024–2026]`,
          ];
          for (const line of lines) {
            sendEvent({ type: 'token', content: line + '\n' });
          }
        } else if (qaSearchResults.length > 0) {
          const topQA = qaSearchResults[0];
          const lines = [
            language === 'fil'
              ? `Magandang araw! Batay sa opisyal na alituntunin ukol sa **${topQA.entry.section}**:`
              : `Good day! Based on official guidance regarding **${topQA.entry.section}**:`,
            '',
            topQA.entry.answer,
            '',
            `📌 **Pinagbatayan:** [${topQA.entry.section} - ${topQA.entry.id}]`,
          ];

          for (const line of lines) {
            sendEvent({ type: 'token', content: line + '\n' });
          }
        }

        sendEvent({ type: 'done' });
        controller.close();
      },
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        Connection: 'keep-alive',
      },
    });
  } catch (err) {
    console.error('Chat API Error:', err);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
