'use client';

import React, { useEffect, useState } from 'react';
import type {
  DpwhProject,
  DpwhProjectCategory,
  DpwhCitizenReport,
  IslandGroup,
} from '@/lib/dpwh/projects';

interface DpwhProjectsViewProps {
  citizenName?: string;
  onAskInChat?: (prompt: string) => void;
}

const CATEGORIES: (DpwhProjectCategory | 'ALL')[] = [
  'ALL',
  'Bridge & Marine Link',
  'Expressway & Bypass Road',
  'Flood Control & Drainage',
  'Tunnel & Mountain Pass',
  'Public Facility & Hospital',
];

function formatPhpBillions(amount: number): string {
  if (amount >= 1_000_000_000) {
    return `₱${(amount / 1_000_000_000).toFixed(2)}B`;
  }
  if (amount >= 1_000_000) {
    return `₱${(amount / 1_000_000).toFixed(1)}M`;
  }
  return `₱${amount.toLocaleString()}`;
}

export function DpwhProjectsView({
  citizenName = 'Juan Dela Cruz',
  onAskInChat,
}: DpwhProjectsViewProps) {
  const [projects, setProjects] = useState<DpwhProject[]>([]);
  const [reports, setReports] = useState<DpwhCitizenReport[]>([]);
  const [loading, setLoading] = useState(true);

  const [islandFilter, setIslandFilter] = useState<IslandGroup | 'ALL'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<DpwhProjectCategory | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const [stats, setStats] = useState({
    totalCount: 0,
    nationwideTotal: 12,
    totalBudgetPhp: 0,
    averageProgress: 0,
    byIsland: { Luzon: 6, Visayas: 2, Mindanao: 4 },
  });

  // Selected project for detail & citizen transparency report drawer
  const [selectedProject, setSelectedProject] = useState<DpwhProject | null>(null);
  const [observationType, setObservationType] = useState<DpwhCitizenReport['observationType']>(
    'Progress Verification',
  );
  const [comment, setComment] = useState('');
  const [submittingReport, setSubmittingReport] = useState(false);
  const [reportFeedback, setReportFeedback] = useState<string | null>(null);

  const loadProjects = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (islandFilter !== 'ALL') params.set('islandGroup', islandFilter);
      if (categoryFilter !== 'ALL') params.set('category', categoryFilter);
      if (searchQuery.trim()) params.set('search', searchQuery.trim());

      const res = await fetch(`/api/dpwh/projects?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setProjects(data.projects || []);
        if (data.stats) setStats(data.stats);
        if (Array.isArray(data.reports)) setReports(data.reports);
      }
    } catch (err) {
      console.error('Failed loading DPWH projects:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadProjects();
  }, [islandFilter, categoryFilter, searchQuery]);

  const handleSubmitObservation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !comment.trim()) return;
    setSubmittingReport(true);
    setReportFeedback(null);

    try {
      const res = await fetch('/api/dpwh/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: selectedProject.id,
          reporterName: citizenName,
          observationType,
          comment: comment.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit report');
      }
      setComment('');
      setReportFeedback(
        `Citizen Transparency Report recorded! Reference: ${data.report.referenceNumber}`,
      );
      void loadProjects();
    } catch (err: unknown) {
      setReportFeedback(err instanceof Error ? err.message : 'Error submitting report');
    } finally {
      setSubmittingReport(false);
    }
  };

  return (
    <div className="min-h-0 flex-1 overflow-y-auto px-4 sm:px-6 py-6">
      <div className="mx-auto max-w-6xl space-y-6">
        {/* Header Banner */}
        <div className="rounded-2xl border border-slate-200 bg-gradient-to-r from-slate-900 via-slate-800 to-amber-950 p-6 text-white shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-2 rounded-full bg-amber-500/20 border border-amber-400/30 px-3 py-1 text-xs font-semibold text-amber-300">
                <span>🏗️ DPWH INFRASTRUCTURE TRANSPARENCY PORTAL</span>
                <span>•</span>
                <span>NATIONWIDE LIVE TRACKER</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                Department of Public Works and Highways (DPWH)
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
                Real-time nationwide monitoring of major bridges, expressways, mountain tunnels, flood
                control systems, and specialty hospitals currently under construction across Luzon,
                Visayas, and Mindanao.
              </p>
            </div>

            <div className="flex flex-col items-start sm:items-end gap-1 rounded-xl bg-white/10 px-4 py-3 backdrop-blur-xs border border-white/10">
              <span className="text-[11px] uppercase tracking-wider text-amber-300 font-semibold">
                DPWH Citizen Hotline
              </span>
              <span className="text-lg font-bold">165-02 / (02) 5304-3000</span>
              <span className="text-[11px] text-slate-300">citizens_feedback@dpwh.gov.ph</span>
            </div>
          </div>

          {/* Summary KPI Grid */}
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-xl bg-white/10 p-3.5 border border-white/10">
              <p className="text-[11px] font-medium text-slate-300">Active Projects Shown</p>
              <p className="mt-1 text-2xl font-bold text-white">
                {stats.totalCount}{' '}
                <span className="text-xs font-normal text-slate-300">
                  of {stats.nationwideTotal} nationwide
                </span>
              </p>
            </div>
            <div className="rounded-xl bg-white/10 p-3.5 border border-white/10">
              <p className="text-[11px] font-medium text-slate-300">Combined Contract Cost</p>
              <p className="mt-1 text-2xl font-bold text-amber-300">
                {formatPhpBillions(stats.totalBudgetPhp)}
              </p>
            </div>
            <div className="rounded-xl bg-white/10 p-3.5 border border-white/10">
              <p className="text-[11px] font-medium text-slate-300">Avg. Physical Accomplishment</p>
              <p className="mt-1 text-2xl font-bold text-emerald-400">{stats.averageProgress}%</p>
            </div>
            <div className="rounded-xl bg-white/10 p-3.5 border border-white/10">
              <p className="text-[11px] font-medium text-slate-300">Island Group Coverage</p>
              <p className="mt-1 text-xs font-semibold text-white leading-relaxed">
                Luzon: {stats.byIsland.Luzon} · Visayas: {stats.byIsland.Visayas} · Mindanao:{' '}
                {stats.byIsland.Mindanao}
              </p>
            </div>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-2xs space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Island Group Tabs */}
            <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Island Group Filter">
              {(['ALL', 'Luzon', 'Visayas', 'Mindanao'] as const).map((island) => {
                const active = islandFilter === island;
                return (
                  <button
                    key={island}
                    type="button"
                    onClick={() => setIslandFilter(island)}
                    className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
                      active
                        ? 'bg-slate-900 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {island === 'ALL' ? '🇵🇭 All Philippines' : island}
                  </button>
                );
              })}
            </div>

            {/* Search Input */}
            <div className="relative flex-1 min-w-[240px] max-w-md">
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search bridge, tunnel, flood control, province, or contract ID..."
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 outline-none focus:border-slate-900 focus:bg-white"
              />
            </div>
          </div>

          {/* Category Pills */}
          <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-100">
            <span className="text-[11px] font-semibold text-slate-400 mr-1">Infrastructure Type:</span>
            {CATEGORIES.map((cat) => {
              const active = categoryFilter === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategoryFilter(cat)}
                  className={`rounded-lg px-2.5 py-1 text-[11px] font-medium transition-all ${
                    active
                      ? 'bg-amber-500 text-slate-950 font-semibold'
                      : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200/70'
                  }`}
                >
                  {cat === 'ALL' ? 'All Categories' : cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Projects Grid */}
        {loading ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center text-sm text-slate-500">
            Loading nationwide DPWH projects...
          </div>
        ) : projects.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center space-y-2">
            <p className="text-base font-semibold text-slate-800">
              No DPWH projects match your current filter.
            </p>
            <button
              type="button"
              onClick={() => {
                setIslandFilter('ALL');
                setCategoryFilter('ALL');
                setSearchQuery('');
              }}
              className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-semibold text-white"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {projects.map((project) => {
              const isNearCompletion = project.physicalProgress >= 80;
              return (
                <article
                  key={project.id}
                  className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs transition-all hover:border-slate-300 hover:shadow-md"
                >
                  <div className="space-y-3">
                    {/* Top Badges */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <span className="rounded-md bg-slate-900 px-2 py-0.5 text-[10px] font-bold text-white uppercase">
                          {project.islandGroup}
                        </span>
                        <span className="rounded-md bg-amber-50 border border-amber-200 px-2 py-0.5 text-[10px] font-semibold text-amber-900">
                          {project.category}
                        </span>
                      </div>
                      <span
                        className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                          isNearCompletion
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-blue-50 text-blue-700'
                        }`}
                      >
                        {project.status}
                      </span>
                    </div>

                    {/* Title & Location */}
                    <div>
                      <div className="text-[11px] font-mono text-slate-400">
                        Contract ID: {project.contractId} · {project.region}
                      </div>
                      <h2 className="mt-0.5 text-base font-bold text-slate-900 leading-snug">
                        {project.title}
                      </h2>
                      <p className="mt-1 text-xs font-medium text-slate-600">
                        📍 {project.cityMunicipality} ({project.province})
                      </p>
                    </div>

                    {/* Physical Progress Bar */}
                    <div className="rounded-xl bg-slate-50 p-3 border border-slate-100 space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-700">
                          Physical Accomplishment
                        </span>
                        <span className="font-bold text-slate-900">
                          {project.physicalProgress.toFixed(1)}%
                        </span>
                      </div>
                      <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200">
                        <div
                          className={`h-full rounded-full transition-all ${
                            isNearCompletion ? 'bg-emerald-600' : 'bg-amber-500'
                          }`}
                          style={{ width: `${Math.min(100, project.physicalProgress)}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
                        <span>Scope: {project.lengthOrScope}</span>
                        <span>Target: {project.targetCompletionDate}</span>
                      </div>
                    </div>

                    {/* Description & Public Impact */}
                    <p className="text-xs text-slate-600 leading-relaxed">{project.description}</p>

                    <div className="rounded-xl bg-emerald-50/70 border border-emerald-200/70 px-3 py-2 text-[11.5px] text-emerald-950">
                      <span className="font-bold">Citizen Impact: </span>
                      {project.publicImpact}
                    </div>

                    {/* Metadata Grid */}
                    <div className="grid grid-cols-2 gap-2 pt-1 text-[11px] text-slate-600 border-t border-slate-100">
                      <div>
                        <span className="text-slate-400 block">Allocation / Budget</span>
                        <span className="font-bold text-slate-900">
                          {formatPhpBillions(project.budgetPhp)}
                        </span>{' '}
                        <span className="text-[10px] text-slate-500">({project.fundingSource})</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Contractor</span>
                        <span className="font-medium text-slate-800 line-clamp-1">
                          {project.contractor}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Card Footer Buttons */}
                  <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedProject(project);
                        setReportFeedback(null);
                      }}
                      className="flex-1 rounded-xl bg-slate-900 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-all"
                    >
                      Milestones &amp; Citizen Watch
                    </button>
                    {onAskInChat && (
                      <button
                        type="button"
                        onClick={() =>
                          onAskInChat(
                            `Tell me about the DPWH ${project.title} (${project.contractId}) in ${project.cityMunicipality}, its current physical progress, budget, and expected completion date.`,
                          )
                        }
                        className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                      >
                        Ask AI
                      </button>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {/* Recent Citizen Transparency Reports */}
        {reports.length > 0 && (
          <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
            <h3 className="text-sm font-bold text-slate-900">
              Recent Citizen Infrastructure Watch Reports ({reports.length})
            </h3>
            <div className="grid gap-2 sm:grid-cols-2">
              {reports.slice(0, 4).map((rep) => (
                <div
                  key={rep.id}
                  className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-amber-800">
                      {rep.referenceNumber}
                    </span>
                    <span className="rounded-md bg-white px-2 py-0.5 text-[10px] font-semibold text-slate-600 border border-slate-200">
                      {rep.observationType}
                    </span>
                  </div>
                  <p className="text-slate-700">{rep.comment}</p>
                  <p className="text-[10px] text-slate-400">
                    Contract: {rep.contractId} · Reported by {rep.reporterName}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Project Engineering Milestones & Citizen Watch Modal */}
      {selectedProject && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={selectedProject.title}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs"
        >
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl space-y-5">
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <span className="text-xs font-mono font-semibold text-amber-700">
                  {selectedProject.contractId} · {selectedProject.implementingOffice}
                </span>
                <h2 className="mt-1 text-lg font-bold text-slate-900">{selectedProject.title}</h2>
                <p className="text-xs text-slate-500">
                  {selectedProject.cityMunicipality}, {selectedProject.province} (
                  {selectedProject.region})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedProject(null)}
                className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600 hover:bg-slate-200"
              >
                Close ✕
              </button>
            </div>

            {/* Engineering Milestones Timeline */}
            <div className="space-y-2.5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Construction &amp; Engineering Milestones ({selectedProject.physicalProgress}% Done)
              </h3>
              <div className="space-y-2">
                {selectedProject.milestones.map((m, idx) => (
                  <div
                    key={idx}
                    className={`flex items-center justify-between rounded-xl border p-3 text-xs ${
                      m.completed
                        ? 'border-emerald-200 bg-emerald-50/50 text-emerald-950'
                        : 'border-slate-200 bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`flex h-5 w-5 items-center justify-center rounded-full text-[11px] font-bold ${
                          m.completed
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-300 text-slate-700'
                        }`}
                      >
                        {m.completed ? '✓' : idx + 1}
                      </span>
                      <span className="font-medium">{m.label}</span>
                    </div>
                    <span className="font-mono text-[11px] text-slate-500">{m.date}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Citizen Infrastructure Watch Form */}
            <form
              onSubmit={handleSubmitObservation}
              className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Submit Citizen Infrastructure Transparency Report
                </h3>
                <span className="text-[11px] text-slate-500">FOI &amp; RA 11032 Compliant</span>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Observation Category
                  </label>
                  <select
                    value={observationType}
                    onChange={(e) =>
                      setObservationType(e.target.value as DpwhCitizenReport['observationType'])
                    }
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900"
                  >
                    <option value="Progress Verification">Progress Verification</option>
                    <option value="Safety / Traffic Concern">Safety / Traffic Concern</option>
                    <option value="Flood / Drainage Issue">Flood / Drainage Issue</option>
                    <option value="General Inquiry">General Inquiry</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Citizen Observer
                  </label>
                  <input
                    type="text"
                    value={citizenName}
                    disabled
                    className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2 text-xs text-slate-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Field Observation or Inquiry Details
                </label>
                <textarea
                  rows={2}
                  required
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Describe on-site construction progress, road safety signage, or flood drainage observations..."
                  className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-xs text-slate-900 outline-none focus:border-slate-900"
                />
              </div>

              {reportFeedback && (
                <div className="rounded-lg bg-emerald-100 border border-emerald-300 px-3 py-2 text-xs font-semibold text-emerald-900">
                  {reportFeedback}
                </div>
              )}

              <div className="flex justify-end gap-2">
                <button
                  type="submit"
                  disabled={submittingReport || !comment.trim()}
                  className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400 disabled:opacity-50"
                >
                  {submittingReport ? 'Submitting...' : 'Submit Official Observation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
