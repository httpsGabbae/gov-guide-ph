import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase/service';
import {
  PROFILES,
  createInitialChecklists,
  createInitialInspections,
  createInitialSavedFiles,
} from '@/lib/citizen/defaults';
import type { Json } from '@/lib/supabase/types';
import type {
  ApplicantProfile,
  SavedVaultFile,
  ChecklistRequirementItem,
  InspectionReport,
} from '@/lib/services/charter-sources';

const DEFAULT_CITIZEN_ID = PROFILES.jobseeker.id;

interface CitizenDetailsPayload {
  applicant: ApplicantProfile;
  saved_files: SavedVaultFile[];
  checklists: ChecklistRequirementItem[];
  inspections: InspectionReport[];
  [key: string]: unknown;
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const citizenId = searchParams.get('citizenId') || DEFAULT_CITIZEN_ID;

    const supabase = createServiceClient();
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', citizenId)
      .maybeSingle();

    if (!error && profile) {
      const consent = (profile.consent_settings as CitizenDetailsPayload) || {};
      if (consent.applicant && Array.isArray(consent.saved_files)) {
        return NextResponse.json({
          ok: true,
          source: 'supabase',
          applicant: consent.applicant,
          savedFiles: consent.saved_files,
          checklistItems: consent.checklists || createInitialChecklists(),
          inspections: consent.inspections || createInitialInspections(),
        });
      }
    }

    // Determine initial persona defaults based on citizenId
    const isMarried = citizenId === PROFILES.married_applicant.id;
    const initialApplicant = isMarried ? PROFILES.married_applicant : PROFILES.jobseeker;
    const initialFiles = createInitialSavedFiles();
    const initialChecklists = createInitialChecklists();
    const initialInspections = createInitialInspections();

    // Persist initial state directly to Supabase profiles
    try {
      await supabase.from('profiles').upsert(
        {
          id: citizenId,
          full_name: initialApplicant.display_name,
          email: `${initialApplicant.role}@govguide.ph`,
          role: 'citizen',
          consent_settings: {
            ephemeral_biometrics: true,
            audit_logging: true,
            ai_assisted: true,
            applicant: initialApplicant,
            saved_files: initialFiles,
            checklists: initialChecklists,
            inspections: initialInspections,
          } as unknown as Json,
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'id' },
      );
    } catch {
      // safe ignore in transient connection glitches
    }

    return NextResponse.json({
      ok: true,
      source: 'supabase_initialized',
      applicant: initialApplicant,
      savedFiles: initialFiles,
      checklistItems: initialChecklists,
      inspections: initialInspections,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to retrieve citizen details';
    return NextResponse.json({ ok: false, message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      citizenId = DEFAULT_CITIZEN_ID,
      applicant,
      savedFiles,
      checklistItems,
      inspections,
    } = body;

    if (!applicant) {
      return NextResponse.json(
        { ok: false, message: 'Invalid payload: applicant profile is required' },
        { status: 400 },
      );
    }

    const supabase = createServiceClient();
    const now = new Date().toISOString();

    const { error } = await supabase.from('profiles').upsert(
      {
        id: citizenId,
        full_name: applicant.display_name || 'Citizen Applicant',
        email: `${applicant.role || 'citizen'}@govguide.ph`,
        role: 'citizen',
        consent_settings: {
          ephemeral_biometrics: true,
          audit_logging: true,
          ai_assisted: true,
          applicant,
          saved_files: Array.isArray(savedFiles) ? savedFiles : [],
          checklists: Array.isArray(checklistItems) ? checklistItems : [],
          inspections: Array.isArray(inspections) ? inspections : [],
        } as unknown as Json,
        updated_at: now,
      },
      { onConflict: 'id' },
    );

    if (error) {
      return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
    }

    return NextResponse.json({ ok: true, source: 'supabase', updated_at: now });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to save citizen details';
    return NextResponse.json({ ok: false, message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const citizenId = searchParams.get('citizenId') || DEFAULT_CITIZEN_ID;

    const isMarried = citizenId === PROFILES.married_applicant.id;
    const initialApplicant = isMarried ? PROFILES.married_applicant : PROFILES.jobseeker;
    const initialFiles = createInitialSavedFiles();
    const initialChecklists = createInitialChecklists();
    const initialInspections = createInitialInspections();

    const supabase = createServiceClient();
    await supabase.from('profiles').update({
      full_name: initialApplicant.display_name,
      consent_settings: {
        ephemeral_biometrics: true,
        audit_logging: true,
        ai_assisted: true,
        applicant: initialApplicant,
        saved_files: initialFiles,
        checklists: initialChecklists,
        inspections: initialInspections,
      } as unknown as Json,
      updated_at: new Date().toISOString(),
    }).eq('id', citizenId);

    return NextResponse.json({ ok: true, reset_citizen_id: citizenId });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to reset citizen details';
    return NextResponse.json({ ok: false, message }, { status: 500 });
  }
}
