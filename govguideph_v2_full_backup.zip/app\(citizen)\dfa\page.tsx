'use client';

import React from 'react';
import Link from 'next/link';
import { ArrowLeft, Shield } from 'lucide-react';
import { DfaAppointmentView } from '@/components/dfa/DfaAppointmentView';

export default function DfaStandalonePage() {
  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900">
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200 px-4 md:px-6 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-800 transition"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back to GovGuide PH
            </Link>
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-bold text-slate-900">
                DFA Consular Passport Appointment Portal
              </span>
            </div>
          </div>
          <Link
            href="/dpwh"
            className="text-xs font-semibold text-blue-600 hover:text-blue-800 transition"
          >
            View DPWH Nationwide Projects →
          </Link>
        </div>
      </header>
      <main className="py-4">
        <DfaAppointmentView />
      </main>
    </div>
  );
}
